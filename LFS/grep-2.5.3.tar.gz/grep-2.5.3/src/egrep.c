#define EGREP_PROGRAM
#include "grep.c"
